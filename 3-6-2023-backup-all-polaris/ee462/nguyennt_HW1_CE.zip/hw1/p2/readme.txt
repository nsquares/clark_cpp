Nathan Nguyen

I worked alone on this problem. I did not use any sources.


$ fc.sh /etc
final ans: 252

$ fc.sh /usr/bin/
final ans: 1649

$ fc.sh /lib
final ans: 136

$ fc.sh temp2359823
temp2359823 is not a directory. Quitting.
