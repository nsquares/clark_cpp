Nathan Nguyen

I worked on this problem alone. I did not look up anything extensive.



[nguyennt@polaris:~/ee462/hw3/p2]$ !g
gcc info.c -o info
[nguyennt@polaris:~/ee462/hw3/p2]$ !.
./info


[child] PID: 2197
[child] parent's PID: 2196
[child] cwd: /tmp
[child] current executable: /home/nguyennt/ee462/hw3/p2/info
[original] PID: 2196
[original] parent's PID: 30855
[original] cwd: /home/nguyennt/ee462/hw3/p2
[original] current executable: /home/nguyennt/ee462/hw3/p2/info


[nguyennt@polaris:~/ee462/hw3/p2]$

