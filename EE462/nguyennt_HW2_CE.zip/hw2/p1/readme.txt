Nathan Nguyen

I worked alone on this problem.

I did not use a non-trivial amount of content.

