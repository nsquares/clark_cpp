

Nathan Nguyen

gcc -o driver2.out driver2.c -I/data/class/ee462sp23/public/p2/include/. -L/data/class/ee462sp23/public/p2/lib/. -lsimrand
