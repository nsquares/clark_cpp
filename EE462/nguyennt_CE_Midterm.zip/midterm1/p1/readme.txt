
Nathan Nguyen


The all rule builds the final binary file.

The client1.out rule builds the final binary file.

The client1.o rule builds the object file from the client source code.

The set.o rule builds the object file of the set.c implementation.

The stack.o rule builds the object file of the stack.c implementation.

The clean rule removes all emacs temp files, binary files, and object files.


PHONY lists all the helper rules.   
